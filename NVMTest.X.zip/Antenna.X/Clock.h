/* 
 * File:   Clock.h
 * Author: Connor
 *
 * Created on November 27, 2025, 11:09 AM
 */

#ifndef CLOCK_H
#define	CLOCK_H

#ifdef	__cplusplus
extern "C" {
#endif

#ifndef _XTAL_FREQ

#define _XTAL_FREQ 32000000U
#endif

 void CLOCK_Initialize(void);


    
#ifdef	__cplusplus
}
#endif

#endif	/* CLOCK_H */

