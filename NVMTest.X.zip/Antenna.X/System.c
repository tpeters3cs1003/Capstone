#include "System.h"
#include "Pins.h"
#include "NVM.h"
#include "I2C.h"
#define STEP_DELAY_MS 50 

void SYSTEM_Initialize(void)
{
    CLOCK_Initialize();
    PIN_MANAGER_Initialize();
    INTERRUPT_Initialize();
    NVM_Initialize();
}

void SetUpDriver(uint8_t Res)
{ 
    //Fixed Steps
    SR = Res * 5;
    // 15096 = 1 sec
    if (Res == 1)
    {
    CountMax = 15096;
    EN_SetLow();
    STBY_SetHigh(); 
    M0_SetLow(); 
    M1_SetLow();
    STEP_M2_SetLow();
    DIR_M3_SetHigh();   
    __delay_ms(2); 
    STBY_SetLow();
    __delay_ms(2);
    EN_SetHigh();
    STBY_SetHigh();
    }
        if (Res == 2)
    {
    CountMax = 7548; 
    EN_SetLow();
    STBY_SetHigh(); 
    M0_SetHigh(); 
    M1_SetLow();
    STEP_M2_SetLow();
    DIR_M3_SetHigh();   
    __delay_ms(2); 
    STBY_SetLow();
    __delay_ms(2);
    EN_SetHigh();
    STBY_SetHigh();
    }
        if (Res == 4)
    {
    CountMax = 3774; 
    EN_SetLow();
    STBY_SetHigh(); 
    M0_SetLow(); 
    M1_SetHigh();
    STEP_M2_SetLow();
    DIR_M3_SetHigh();   
    __delay_ms(2); 
    STBY_SetLow();
    __delay_ms(2);
    EN_SetHigh();
    STBY_SetHigh();
    }
        if (Res == 8)
    {
    CountMax = 1887;       
    EN_SetLow();
    STBY_SetHigh(); 
    M0_SetHigh(); 
    M1_SetHigh();
    STEP_M2_SetLow();
    DIR_M3_SetHigh();   
    __delay_ms(2); 
    STBY_SetLow();
    __delay_ms(2);
    EN_SetHigh();
    STBY_SetHigh();
    }
        if (Res == 16)
    {
    CountMax = 944;
    EN_SetLow();
    STBY_SetHigh(); 
    M0_SetLow(); 
    M1_SetLow();
    STEP_M2_SetHigh();
    DIR_M3_SetHigh();   
    __delay_ms(2); 
    STBY_SetLow();
    __delay_ms(2);
    EN_SetHigh();
    STBY_SetHigh();
    }
    
    __delay_ms(50);
    
}

void StepMotor(int steps, bool clockwise) 
{
    if (Count >= CountMax)
    {
        Count = 0;
        // Set Direction
        if(clockwise) {
            DIR_M3_SetHigh(); 
        } else {
            DIR_M3_SetLow();  
        }

        // Pulse the CLK pin
        for(int i=0; i<steps; i++) {
            STEP_M2_SetHigh(); 
            __delay_ms(STEP_DELAY_MS);
            STEP_M2_SetLow();
 
            Steps++;
            
             //Trial #1 loop
            if(Steps == 20)
            {
                //while(1){}
                //EEPROM_Read_Test(STEPS_ADDRESS);
                //EEPROM_Write_Test(STEPS_ADDRESS,Steps);
            }

            /*
            EEPROM_Write(STEPS_ADDRESS, Steps);
            while(NVM_IsBusy()){}
             */ 
        }
        
    }
    else if(Count<CountMax)
    {
       Count++;
    }  
     
}

void Deploy ()
{

    if (FT == 0)
    {
        Unlock();
        SetUpDriver(8);
        FT = 1;
        Steps = 0;
        __delay_ms(100);
    }
    
    if (SolPos == 0x55)
    {
        if (FixedStep == false)
        {
            if (LimSwD_GetValue() == 0)
            {
               DeployS = 0x55; 
               FT = 0;
               EN_SetLow();
               STBY_SetLow();
               
               ///*
                if (EEPROM_READ(DEPLOYS_ADDRESS) != 0x55)
                {
                 EEPROM_Write(DEPLOYS_ADDRESS, 0x55);
                 while(NVM_IsBusy()){}
                }
                //*/ 
            }

            if (LimSwD_GetValue() == 1)
            {
            StepMotor(1, false);
            }
        }
        
        else if (FixedStep == true)
        {
            StepMotor(SR, false);
            UpdateAddress(DEPLOYS_ADDRESS, 0x55);
            UpdateAddress(DEPLOY_ADDRESS, 0x55);
        }
         
    }
}

void Stow (void)
{
    
    if (FT == 0 && LimSwS_GetValue() != 0)
    {
        Unlock();
        FT = 1;
        Steps = 0;
        SetUpDriver(8);
        __delay_ms(100);
    }
    
    if (SolPos == 0x55)
    {
        if (FixedStep == false)
        {
            if (LimSwS_GetValue() == 0)
            {
               __delay_ms(100);
               
               if (LimSwS_GetValue() == 0)
               {
                 StowS = 0x55;   
                 FT =0;
                 EN_SetLow();
                 STBY_SetLow();
                 __delay_ms(100);
                 Lock();  
                 ///*
                   if (EEPROM_READ(STOWS_ADDRESS) != 0x55)
                    {
                    EEPROM_Write(STOWS_ADDRESS, 0x55);
                    while(NVM_IsBusy()){}
                    }
                 // */ 
               }
             }
                 if (LimSwS_GetValue() == 1)
                 {
                    StepMotor(1, true);
                 }
        }
        else if (FixedStep == true)
        {
            StepMotor(SR, true);
            UpdateAddress(STOWS_ADDRESS, 0x55);
            UpdateAddress(STOW_ADDRESS, 0x55);
        }
            
         
    }
}

void Lock(void)
{
  
    SolA_SetHigh();
    SolB_SetLow();
    __delay_ms(500);
    SolA_SetLow();
    SolB_SetLow();
    SolPos = 0xAA;
    UpdateAddress(SOL_POS_ADDRESS, SolPos);
}

void Unlock(void)
{

    SolA_SetLow();
    SolB_SetHigh();
    __delay_ms(500);
    SolA_SetLow();
    SolB_SetLow();
    SolPos = 0x55;
    UpdateAddress(SOL_POS_ADDRESS, SolPos);
}

void CheckPos(void)
{
    if (LimSwS_GetValue() == 0 && LimSwD_GetValue() == 1 )
    {
        Stowed = 0xAA;
        Deployed = 0x55;
        /*
        if (EEPROM_READ(STOW_ADDRESS) != 0xAA)
        {
           EEPROM_Write(STOW_ADDRESS, 0xAA);
           while(NVM_IsBusy()){}
        }
        if (EEPROM_READ(DEPLOY_ADDRESS) != 0x55)
        {
           EEPROM_Write(DEPLOY_ADDRESS, 0x55);
           while(NVM_IsBusy()){}
        }      
       // */      
    }
    else if (LimSwS_GetValue() == 1 && LimSwD_GetValue() == 0 )
    {
        Stowed = 0x55;
        Deployed = 0xAA;
        /*        
        if (EEPROM_READ(STOW_ADDRESS) != 0x55)
        {
           EEPROM_Write(STOW_ADDRESS, 0x55);
           while(NVM_IsBusy()){}
        }
        if (EEPROM_READ(DEPLOY_ADDRESS) != 0xAA)
        {
           EEPROM_Write(DEPLOY_ADDRESS, 0xAA);
           while(NVM_IsBusy()){}
        }
         //*/ 
    }
    else if (LimSwS_GetValue() == 1 && LimSwD_GetValue() == 1 )
    {
        Stowed = 0x55;
        Deployed = 0x55;
        /*
        if (EEPROM_READ(STOW_ADDRESS) != 0x55)
        {
           EEPROM_Write(STOW_ADDRESS, 0x55);
           while(NVM_IsBusy()){}
        }
        if (EEPROM_READ(DEPLOY_ADDRESS) != 0x55)
        {
           EEPROM_Write(DEPLOY_ADDRESS, 0x55);
           while(NVM_IsBusy()){}
        }
         // */
    }
    else if (LimSwS_GetValue() == 0 && LimSwD_GetValue() == 0 )
    {
        Stowed = EEPROM_READ(STOW_ADDRESS);
        Deployed = EEPROM_READ(DEPLOY_ADDRESS);
        FixedStep = true;
        
    }
}



void UpdateData(void)
{
    UpdateAddress(SOL_POS_ADDRESS, SolPos);
    UpdateAddress(STOWS_ADDRESS, StowS);
    UpdateAddress(DEPLOYS_ADDRESS, DeployS);
    UpdateAddress(STOW_ADDRESS, Stowed);
    UpdateAddress(DEPLOY_ADDRESS, Deployed);
    UpdateAddress(STEPS_ADDRESS, Steps);
    while(NVM_IsBusy()){}
}

void UpdateAddress(eeprom_address_t Address, uint8_t NewData)
{
   while(NVM_IsBusy()){}
   
   if (EEPROM_READ(Address) != NewData)
   {
   EEPROM_Write(Address, NewData);
   while(NVM_IsBusy()){}    
   }
}