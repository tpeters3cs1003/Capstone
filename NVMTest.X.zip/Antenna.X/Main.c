/* 
 * File:   Main.c
 * Author: Connor
 *
 * Created on November 27, 2025, 11:12 AM
 */

#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
#include "System.h"
#include "I2C.h"

uint8_t x=1;
uint8_t Test = 0;


/*
 * 
 */



void main(void)
{
 
    SYSTEM_Initialize();
    NVM_UnlockKeySet(UNLOCK_KEY); 
    //SetUpDriver(2);
    Lock();
    I2C_Slave_Init();

    


   // Use the macro from NVM.h
    
    SolPos = EEPROM_READ(SOL_POS_ADDRESS);
    DeployS = EEPROM_READ(DEPLOYS_ADDRESS);
    Deployed = EEPROM_READ(DEPLOY_ADDRESS);
    StowS = EEPROM_READ(STOWS_ADDRESS);
    Stowed = EEPROM_READ(STOW_ADDRESS);
    Steps = EEPROM_READ(STEPS_ADDRESS);
    
    I2C_BuildTxFrame(MSG_BOOT, SolPos, StowS, DeployS, Stowed, Deployed, Steps);
    
    while (1)
    {
        //StepMotor(1,true);
        
       //Need to recieve an Deploy and Stow Signals
       CheckPos();
          
       if (ControlS_GetValue() == 0)
       {  
           while(ControlS_GetValue() == 0){}
            
           if (Test == 0)
           {
               StowS = 0x55;
               DeployS = 0xAA;
               /*
             UpdateAddress(STOWS_ADDRESS, StowS);
             UpdateAddress(DEPLOYS_ADDRESS, DeployS);
               // */ 
               /*
           if (EEPROM_READ(DEPLOYS_ADDRESS) != 0xAA)
           {
           EEPROM_Write(DEPLOYS_ADDRESS, 0xAA);
           while(NVM_IsBusy()){}
            }
            if (EEPROM_READ(STOWS_ADDRESS) != 0x55)
           {
           EEPROM_Write(STOWS_ADDRESS, 0x55);
           while(NVM_IsBusy()){}
            }    
                //*/          
               Test=1;
           }
           else if (Test == 1)
           {
               StowS = 0xAA;
               DeployS = 0x55;
               /*
           if (EEPROM_READ(DEPLOYS_ADDRESS) != 0x55)
           {
           EEPROM_Write(DEPLOYS_ADDRESS, 0x55);
           while(NVM_IsBusy()){}
            }
            if (EEPROM_READ(STOWS_ADDRESS) != 0xAA)
           {
           EEPROM_Write(STOWS_ADDRESS, 0xAA);
           while(NVM_IsBusy()){}
            }  
                //*/  
               Test = 0;
               
           }
             
       }
       

            UpdateData();
       //*/
       
       if (Deployed == 0xAA )
       {
           if (DeployS == 0xAA)
           {
            DeployS = 0x55;
            FT = 0;
            EN_SetLow();
            STBY_SetLow();
            ///*
            EEPROM_Write(DEPLOYS_ADDRESS, 0x55);
            while(NVM_IsBusy()){}
             //
           }
             
           if(StowS== 0xAA)
           {
               Stow();
           }  
       }
       
      if (Stowed == 0xAA )
       {
        if (StowS == 0xAA)
           {
            StowS = 0x55;
            FT = 0;
            EN_SetLow();
            STBY_SetLow();
            ///*
            EEPROM_Write(STOWS_ADDRESS, 0x55);
            while(NVM_IsBusy()){}
            // 
                   Lock();
           }
           if(DeployS== 0xAA)
           {
               Deploy();
           }
               
       }
       
       if ( Stowed == 0x55 && Deployed == 0x55)
       {
           if (DeployS == 0xAA)
           {
               Deploy();
           }
           else if (StowS == 0xAA)
           {
               Stow();
           }
           // else if request signal 
       }
       //*/
      
    }
}

