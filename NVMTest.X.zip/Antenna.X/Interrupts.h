/* 
 * File:   Interrupts.h
 * Author: Connor
 *
 * Created on November 27, 2025, 12:30 PM
 */

#ifndef INTERRUPTS_H
#define	INTERRUPTS_H

#ifdef	__cplusplus
extern "C" {
#endif

#define INTERRUPT_GlobalInterruptEnable() (INTCONbits.GIE = 1)

/**
 * @ingroup interrupt
 * @brief Disables global interrupts.
 * @param None.
 * @return None.
 */
#define INTERRUPT_GlobalInterruptDisable() (INTCONbits.GIE = 0)

/**
 * @ingroup interrupt
 * @brief Returns the Global Interrupt Enable bit status.
 * @param None.
 * @retval 0 - Global interrupt disabled.
 * @retval 1 - Global interrupt enabled.
 */
#define INTERRUPT_GlobalInterruptStatus() (INTCONbits.GIE)

/**
 * @ingroup interrupt
 * @brief Enables peripheral interrupts.
 * @param None.
 * @return None.
 */
#define INTERRUPT_PeripheralInterruptEnable() (INTCONbits.PEIE = 1)

/**
 * @ingroup interrupt
 * @brief Disables peripheral interrupts.
 * @param None.
 * @return None.
 */
#define INTERRUPT_PeripheralInterruptDisable() (INTCONbits.PEIE = 0)


void INTERRUPT_Initialize (void);



#define EXT_INT_InterruptFlagClear()       (PIR0bits.INTF = 0)
#define EXT_INT_InterruptDisable()     (PIE0bits.INTE = 0)
#define EXT_INT_InterruptEnable()       (PIE0bits.INTE = 1)
#define EXT_INT_risingEdgeSet()          (INTCONbits.INTEDG = 1)
#define EXT_INT_fallingEdgeSet()          (INTCONbits.INTEDG = 0)


void INT_ISR(void);


void INT_CallBack(void);


void INT_SetInterruptHandler(void (* InterruptHandler)(void));


extern void (*INT_InterruptHandler)(void);


void INT_DefaultInterruptHandler(void);


#ifdef	__cplusplus
}
#endif

#endif	/* INTERRUPTS_H */

