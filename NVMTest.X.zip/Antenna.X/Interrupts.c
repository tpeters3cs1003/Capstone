#include "Interrupts.h"

#include "System.h"

#include "Pins.h"



void (*INT_InterruptHandler)(void);



void  INTERRUPT_Initialize (void)

{

    // Clear the interrupt flag

    // Set the external interrupt edge detect

    EXT_INT_InterruptFlagClear();   

    EXT_INT_risingEdgeSet();

    // Set Default Interrupt Handler

    INT_SetInterruptHandler(INT_DefaultInterruptHandler);

    // EXT_INT_InterruptEnable();



}





void INT_ISR(void)

{

    EXT_INT_InterruptFlagClear();



    // Callback function gets called everytime this ISR executes

    INT_CallBack();    

}





void INT_CallBack(void)

{

    // Add your custom callback code here

    if(INT_InterruptHandler)

    {

        INT_InterruptHandler();

    }

}



void INT_SetInterruptHandler(void (* InterruptHandler)(void)){

    INT_InterruptHandler = InterruptHandler;

}



void INT_DefaultInterruptHandler(void){

    // add your INT interrupt custom code

    // or set custom function using INT_SetInterruptHandler()

}

/**

 End of File

*/
