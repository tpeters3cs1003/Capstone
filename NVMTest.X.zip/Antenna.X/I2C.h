/* 
 * File:   I2C.h
 * Author: Connor
 *
 * Created on March 17, 2026, 4:13 PM

* I2C Slave driver for ALAC antenna controller.

* 

* Pins (via PPS):

*   SCL -> RA3

*   SDA -> RA2

* Slave address: 0x50

*

* Message Frame (8 bytes):

*   Byte 0: Message ID

*   Byte 1: SOL position  (0x00 = unlocked, 0xFF = locked)

*   Byte 2: StowS         (0x00 = false,    0xFF = true)

*   Byte 3: DeployS       (0x00 = false,    0xFF = true)

*   Byte 4: Stowed        (0x00 = false,    0xFF = true)

*   Byte 5: Deployed      (0x00 = false,    0xFF = true)

*   Byte 6: Steps         (current step count)

*   Byte 7: 0x00          (reserved / future parity)

*

* Message IDs (Table 1):

*   0x00  Boot message          -> No response

*   0x01  OBC Position Command  -> Update StowS and DeployS from message

*   0x02  OBC Position Request  -> Reply with ALAC Position Message (0x03)

*   0x03  ALAC Position Message -> Update all fields, send to next node

*   0x04  ALAC Command Request  -> Reply with OBC Position Command (0x01)

*/
 
#ifndef I2C_H

#define I2C_H
 
#ifdef __cplusplus

extern "C" {

#endif
 
#include <xc.h>

#include <stdint.h>

#include <stdbool.h>
 
// ---------------------------------------------------------------------------

// I2C slave address

// ---------------------------------------------------------------------------

#define I2C_SLAVE_ADDR      0x20
 
// ---------------------------------------------------------------------------

// Message frame layout

// ---------------------------------------------------------------------------

#define I2C_FRAME_LEN       8
 
#define I2C_IDX_MSG_ID      0

#define I2C_IDX_SOL_POS     1

#define I2C_IDX_STOWS       2

#define I2C_IDX_DEPLOYS     3

#define I2C_IDX_STOWED      4

#define I2C_IDX_DEPLOYED    5

#define I2C_IDX_STEPS       6

#define I2C_IDX_RESERVED    7
 
// ---------------------------------------------------------------------------

// Message ID values (Table 1)

// ---------------------------------------------------------------------------

#define MSG_BOOT            0x00    // Boot message        -> no response

#define MSG_OBC_CMD         0x01    // OBC Position Command -> update StowS/DeployS

#define MSG_OBC_REQ         0x02    // OBC Position Request -> reply 0x03

#define MSG_ALAC_POS        0x03    // ALAC Position Message -> update all, forward

#define MSG_ALAC_CMD_REQ    0x04    // ALAC Command Request -> reply 0x01
 
// ---------------------------------------------------------------------------

// Encoding conventions matching existing project values

// ---------------------------------------------------------------------------

#define I2C_TRUE            0xFF

#define I2C_FALSE           0x00
 
// ---------------------------------------------------------------------------

// Flag set by ISR when a complete 8-byte frame has been received

// ---------------------------------------------------------------------------

extern volatile bool i2c_frame_ready;
 
// Raw receive / transmit buffers (ISR-owned)

extern volatile uint8_t i2c_rx_buf[I2C_FRAME_LEN];

extern volatile uint8_t i2c_tx_buf[I2C_FRAME_LEN];
 
// ---------------------------------------------------------------------------

// Translation macros: convert between I2C wire encoding and internal encoding

//   Wire:     0xFF = true,  0x00 = false

//   Internal: 0xAA = true,  0x55 = false

// ---------------------------------------------------------------------------

#define TO_INTERNAL(v)  (((v) == I2C_TRUE) ? 0xAA : 0x55)

#define TO_WIRE(v)      (((v) == 0xAA)     ? I2C_TRUE : I2C_FALSE)
 
// ---------------------------------------------------------------------------

// API

// ---------------------------------------------------------------------------
 
// Initialise MSSP1 as I2C slave on RB5 (SDA) / RB6 (SCL)

void I2C_Slave_Init(void);
 
// Build a transmit frame from current system state and load into tx_buf.

// Call this before the master reads back (MSG_OBC_REQ / MSG_ALAC_CMD_REQ).

// All boolean values should be passed as internal encoding (0xAA / 0x55).

// Steps is a raw count and is passed directly.

void I2C_BuildTxFrame(uint8_t msgID,

                      uint8_t solPos,

                      uint8_t stowS,

                      uint8_t deployS,

                      uint8_t stowed,

                      uint8_t deployed,

                      uint8_t steps);
 
// Process a received frame. Called from main loop when i2c_frame_ready is set.

// Translates wire values to internal encoding and updates system state

// as required by Table 1.

void I2C_ProcessFrame(void);
 
// ISR handler for MSSP1 I2C events and bus collision.

// Must be called from the project's __interrupt() ISR in Interrupts.c.

void I2C_ISR_Handler(void);
 
#ifdef __cplusplus

}

#endif
 
#endif /* I2C_H */

 

