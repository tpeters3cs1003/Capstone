/* 
 * File:   Config.h
 * Author: Connor
 *
 * Created on November 27, 2025, 11:07 AM
 */

#ifndef CONFIG_H
#define	CONFIG_H



#ifdef	__cplusplus
extern "C" {
#endif

#include "Clock.h"


#ifdef	__cplusplus
}
#endif

#endif	/* CONFIG_H */

