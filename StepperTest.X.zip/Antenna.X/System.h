/* 
 * File:   System.h
 * Author: Connor
 *
 * Created on November 27, 2025, 11:20 AM
 */

#ifndef SYSTEM_H
#define	SYSTEM_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <xc.h>
#include <stdint.h>
#include <stdbool.h>
#include "Config.h"
#include "Clock.h"
#include "Pins.h"
#include "Interrupts.h"
#include "NVM.h"

uint8_t DeployS=0;
uint8_t StowS=0;

uint8_t ControlS=0;
uint32_t Count = 0;
uint32_t CountMax = 100000;
uint8_t Steps = 0;
uint8_t SolPos = 0x00;
uint8_t Deployed = 0x00;
uint8_t Stowed = 0x00;
uint8_t FixedStep = 0x00;
uint8_t FT = 0;
uint8_t SR = 0;
uint8_t Trial = 0;
uint8_t Run = 1;
uint8_t TrialRes = 1;

void TrialTracker(void);

void SYSTEM_Initialize(void);

void SetUpDriver (uint8_t Res);

void StepMotor(int steps, bool clockwise);

void Deploy ();

void Stow(void);

void CheckPos(void);

void Lock(void);

void Unlock(void);

void UpdateData(void);

void UpdateAddress(eeprom_address_t Address, uint8_t NewData);


#ifdef	__cplusplus
}
#endif

#endif	/* SYSTEM_H */

