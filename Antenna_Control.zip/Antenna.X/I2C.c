/*
 * File:   I2C.c
 *
 * MSSP1 I2C Slave driver for ALAC antenna controller.
 *
 *
 */

#include "I2C.h"
#include "System.h"
#include "Interrupts.h"
#include "NVM.h"

// ---------------------------------------------------------------------------
// Translation helpers: convert between I2C wire encoding (0xFF/0x00)
// and the project's internal encoding (0xAA/0x55)
// ---------------------------------------------------------------------------
#define TO_INTERNAL(v)  (((v) == I2C_TRUE) ? 0xAA : 0x55)
#define TO_WIRE(v)      (((v) == 0xAA)     ? I2C_TRUE : I2C_FALSE)

// ---------------------------------------------------------------------------
// Shared buffers and flag
// ---------------------------------------------------------------------------
volatile bool    i2c_frame_ready        = false;
volatile uint8_t i2c_rx_buf[I2C_FRAME_LEN];
volatile uint8_t i2c_tx_buf[I2C_FRAME_LEN];

static volatile uint8_t rx_index = 0;
static volatile uint8_t tx_index = 0;

// ---------------------------------------------------------------------------
// I2C_Slave_Init
// ---------------------------------------------------------------------------
void I2C_Slave_Init(void)
{
    // --- PPS unlock ---
    PPSLOCK = 0x55;
    PPSLOCK = 0xAA;
    PPSLOCKbits.PPSLOCKED = 0;

    // Route MSSP1 outputs
    RC4PPS     = 0x14;      // RC4 output -> SCL1
    RC3PPS     = 0x15;      // SDA1
    SSP1CLKPPS = 0x14;      // SCL1 input 
    SSP1DATPPS = 0x13;      // SDA1 input 
    PPSLOCK = 0x55;
    PPSLOCK = 0xAA;
    PPSLOCKbits.PPSLOCKED = 1;

    
    // --- Pin config: open-drain, digital, inputs ---
    TRISCbits.TRISC4 = 1;
    TRISCbits.TRISC3 = 1;
    ANSELCbits.ANSC4 = 0;
    ANSELCbits.ANSC3 = 0;
    ODCONCbits.ODCC4 = 1;
    ODCONCbits.ODCC3 = 1;
    
    SSP1ADD = 0x40;
    
    // --- MSSP1: I2C Slave, 7-bit address ---
    SSP1CON1 |= 0x6; //was 0x00
    SSP1CON2 = 0x01;
    SSP1CON3 = 0x00;
    SSP1CON3bits.BOEN  = 1;         // Buffer overwrite enable
    SSP1CON3bits.AHEN  = 0;
    SSP1CON3bits.DHEN  = 0;
    SSP1CON3bits.SDAHT = 0;

    // 7-bit address, left-aligned
    //SSP1ADD = (uint8_t)(I2C_SLAVE_ADDR << 1);
       // --- Interrupts ---
    PIR3bits.SSP1IF = 0;
    PIR3bits.BCL1IF = 0;
    PIE3bits.SSP1IE = 1;
    PIE3bits.BCL1IE = 1;
    
    // Enable MSSP
    SSP1CON1bits.SSPEN = 1;
}

// ---------------------------------------------------------------------------
// I2C_BuildTxFrame
// ---------------------------------------------------------------------------
void I2C_BuildTxFrame(uint8_t msgID,
                      uint8_t solPos,
                      uint8_t stowS,
                      uint8_t deployS,
                      uint8_t stowed,
                      uint8_t deployed,
                      uint8_t steps)
{
    // Disable interrupts briefly to update tx buffer atomically
    INTCONbits.GIE = 0;

    i2c_tx_buf[I2C_IDX_MSG_ID]   = msgID;
    i2c_tx_buf[I2C_IDX_SOL_POS]  = solPos;
    i2c_tx_buf[I2C_IDX_STOWS]    = stowS;
    i2c_tx_buf[I2C_IDX_DEPLOYS]  = deployS;
    i2c_tx_buf[I2C_IDX_STOWED]   = stowed;
    i2c_tx_buf[I2C_IDX_DEPLOYED] = deployed;
    i2c_tx_buf[I2C_IDX_STEPS]    = steps;
    i2c_tx_buf[I2C_IDX_RESERVED] = 0x00;

    tx_index = 0;   // reset so ISR starts from byte 0 on next read

    INTCONbits.GIE = 1;
}

// ---------------------------------------------------------------------------
// I2C_ProcessFrame
// Called from main loop when i2c_frame_ready is set.
// Implements Table 1 message handling.
// ---------------------------------------------------------------------------
void I2C_ProcessFrame(void)
{
    uint8_t msgID = i2c_rx_buf[I2C_IDX_MSG_ID];

    switch (msgID)
    {
        // ------------------------------------------------------------------
        // 0x00  Boot message ? no action, no response
        // ------------------------------------------------------------------
        case MSG_BOOT:
            break;

        // ------------------------------------------------------------------
        // 0x01  OBC Position Command
        //       Update StowS and DeployS from the received frame
        // ------------------------------------------------------------------
        case MSG_OBC_CMD:
            // Translate 0xFF->0xAA and 0x00->0x55 to match internal convention
            StowS   = (i2c_rx_buf[I2C_IDX_STOWS]);
            DeployS = (i2c_rx_buf[I2C_IDX_DEPLOYS]);

            // Persist to EEPROM
               UpdateAddress(STOWS_ADDRESS, StowS);
               UpdateAddress(DEPLOYS_ADDRESS, DeployS);
            break;

        // ------------------------------------------------------------------
        // 0x02  OBC Position Request
        //       Load current state into tx buffer as ALAC Position Message
        //       (0x03). Master will read it on the next I2C read transaction.
        // ------------------------------------------------------------------
        case MSG_OBC_REQ:
            I2C_BuildTxFrame(
                MSG_ALAC_POS,
                TO_WIRE(SolPos),
                TO_WIRE(StowS),
                TO_WIRE(DeployS),
                TO_WIRE(Stowed),
                TO_WIRE(Deployed),
                Steps
            );
            break;

        // ------------------------------------------------------------------
        // 0x03  ALAC Position Message
        //       Update all state fields from the received frame
        // ------------------------------------------------------------------
        case MSG_ALAC_POS:
            // Translate all incoming 0xFF/0x00 values to internal 0xAA/0x55
            SolPos   = TO_INTERNAL(i2c_rx_buf[I2C_IDX_SOL_POS]);
            StowS    = TO_INTERNAL(i2c_rx_buf[I2C_IDX_STOWS]);
            DeployS  = TO_INTERNAL(i2c_rx_buf[I2C_IDX_DEPLOYS]);
            Stowed   = TO_INTERNAL(i2c_rx_buf[I2C_IDX_STOWED]);
            Deployed = TO_INTERNAL(i2c_rx_buf[I2C_IDX_DEPLOYED]);
            Steps    = i2c_rx_buf[I2C_IDX_STEPS];   // steps is a raw count, no translation needed

            // Persist all updated fields
            //UpdateData();

            // Also prepare the forwarded ALAC Position Message in tx buffer
            // in case another node requests it immediately after
            I2C_BuildTxFrame(
                MSG_ALAC_POS,
                TO_WIRE(SolPos),
                TO_WIRE(StowS),
                TO_WIRE(DeployS),
                TO_WIRE(Stowed),
                TO_WIRE(Deployed),
                Steps
            );
            break;

        // ------------------------------------------------------------------
        // 0x04  ALAC Command Request
        //       Reply with OBC Position Command (0x01) containing current
        //       StowS and DeployS so the requester knows what to do
        // ------------------------------------------------------------------
        case MSG_ALAC_CMD_REQ:
            I2C_BuildTxFrame(
                MSG_OBC_CMD,
                TO_WIRE(SolPos),
                TO_WIRE(StowS),
                TO_WIRE(DeployS),
                TO_WIRE(Stowed),
                TO_WIRE(Deployed),
                Steps
            );
            break;

        default:
            // Unknown message ID ? ignore
            break;
    }
}

// ---------------------------------------------------------------------------
// ISR handler ? called from the project's existing __interrupt() ISR.
// Add  I2C_ISR_Handler();  inside your existing ISR in Interrupts.c
// ---------------------------------------------------------------------------
/*
void I2C_ISR_Handler(void) {
    uint8_t dummy = SSP1BUF; // Read to clear BF
    PIR3bits.SSP1IF = 0;    // Clear Flag
    SSP1CON1bits.CKP = 1;   // FORCE RELEASE
}
*/

void I2C_ISR_Handler(void)
{
    // --- Bus collision recovery -------------------------------------------
    if (PIR3bits.BCL1IF && PIE3bits.BCL1IE) {
        PIR3bits.BCL1IF = 0;
        SSP1CON1bits.SSPEN = 0;
        SSP1CON1bits.SSPEN = 1;
        SSP1CON1bits.CKP = 1;
        tx_index = 0;
        rx_index = 0;
        PIR3bits.SSP1IF = 0;
        return;
    }

    
    // --- MSSP event --------------------------------------------------------
    if (PIR3bits.SSP1IF && PIE3bits.SSP1IE) {
         PIR3bits.SSP1IF = 0;
        //LED2_PIN_Toggle();  
        uint8_t stat     = SSP1STAT;
        volatile uint8_t dummy;

        bool is_read = (stat & 0x04) != 0;  // R/nW: master wants to read
        bool is_data = (stat & 0x20) != 0;  // D/nA: data byte (not address)
        bool bf      = (stat & 0x01) != 0;  // BF:   buffer full

        // Case 1: Address match, master WRITE
        if (!is_data && !is_read) {
            dummy    = SSP1BUF;     // clear BF
            rx_index = 0;
            SSP1CON1bits.CKP = 1;  // release clock stretch

        // Case 2: Data byte from master (master WRITE)
        } else if (is_data && !is_read) {
            if (bf) {
                if (rx_index < I2C_FRAME_LEN) {
                    i2c_rx_buf[rx_index++] = SSP1BUF;
                } 
                
                else {
                    dummy = SSP1BUF;    // discard overflow
                }
                 
                // Frame complete when all 8 bytes received
                if (rx_index >= I2C_FRAME_LEN) {
                    i2c_frame_ready = true;
                    rx_index = 0;
                    I2C_ProcessFrame();
                }
            }
            SSP1CON1bits.CKP = 1;
            
        // Case 3: Address match, master READ ? send first byte
        } else if (!is_data && is_read) {
            dummy    = SSP1BUF;
            tx_index = 0;
            SSP1BUF  = i2c_tx_buf[tx_index++];
            SSP1CON1bits.CKP = 1;

        // Case 4: Master READ, subsequent bytes
        } else if (is_data && is_read) {
            if (SSP1CON2bits.ACKSTAT == 0) {    // master ACK'd, wants more
                SSP1BUF = (tx_index < I2C_FRAME_LEN)
                          ? i2c_tx_buf[tx_index++]
                          : 0x00;
            }
            // master NACK = end of read, do nothing
             SSP1CON1bits.CKP = 1;
        }
         
    }

}

