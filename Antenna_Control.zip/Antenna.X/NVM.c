#include "NVM.h"

__near volatile static uint8_t unlockKeyLow;
__near volatile static uint8_t unlockKeyHigh;

static void (*NVM_Callback) (void) = NULL;

void NVM_Initialize(void)
{
    NVM_StatusClear();
    //Clearing NVM interrupt flag before enabling the interrupt.
    PIR7bits.NVMIF = 0;
    //Enabling NVM interrupt.
    PIE7bits.NVMIE = 1;
}

bool NVM_IsBusy(void)
{
    return (NVMCON1bits.WR || NVMCON1bits.RD);
}

nvm_status_t NVM_StatusGet(void)
{
    if (NVMCON1bits.WRERR == 1)
    {
        return NVM_ERROR;
    }
    else
    {
        return NVM_OK;
    }
}

void NVM_StatusClear(void)
{
    NVMCON1bits.WRERR = 0;
}

void NVM_UnlockKeySet(uint16_t unlockKey)
{
    unlockKeyHigh = (uint8_t) (unlockKey >> 8);
    unlockKeyLow = (uint8_t) unlockKey;
}

void NVM_UnlockKeyClear(void)
{
    unlockKeyHigh = 0x00;
    unlockKeyLow = 0x00;
}

flash_data_t FLASH_Read(flash_address_t address)
{
    //Load NVMADR with address of the word
    NVMADRH = (uint8_t) (address >> 8);
    NVMADRL = (uint8_t) address;

    //Access Program Flash Memory
    NVMCON1bits.NVMREGS = 0;    
    
    //Initiate Read
    NVMCON1bits.RD = 1;      

    return ((flash_data_t) ((NVMDATH << 8) | NVMDATL));
}

nvm_status_t FLASH_RowWrite(flash_address_t address, flash_data_t *dataBuffer)
{    
    uint8_t flashDataCount = PROGMEM_PAGE_SIZE;
    
    //Save global interrupt enable bit value
    uint8_t globalInterruptBitValue = INTCONbits.GIE;   

    //Access program Flash memory
    NVMCON1bits.NVMREGS = 0;   
    
    //Enable write operation
    NVMCON1bits.WREN = 1;   
    
    //Load Write Latches Only
    NVMCON1bits.LWLO = 1;   
    
    while (flashDataCount-- > 0U)
    {
        NVMADRH = (uint8_t) (address >> 8);
        NVMADRL = (uint8_t) address;
        address++;
        
        NVMDATH = (uint8_t) (*dataBuffer >> 8);
        NVMDATL = (uint8_t) (*dataBuffer);
        dataBuffer++;
        
        //If last latch to be written
        if (flashDataCount == 0U)
        {
            //Write program Flash memory 
            NVMCON1bits.LWLO = 0;
        }
        
        //Disable global interrupt
        INTCONbits.GIE = 0;    
        
        //Perform the unlock sequence
        NVMCON2 = unlockKeyLow;
        NVMCON2 = unlockKeyHigh;
        NVMCON1bits.WR = 1;
          
        //Restore global interrupt enable bit value
        INTCONbits.GIE = globalInterruptBitValue; 
    }
    
    //Disable write operation
    NVMCON1bits.WREN = 0;      
    
    if (NVMCON1bits.WRERR == 1) 
    {
        return NVM_ERROR;
    } 
    else 
    {
        return NVM_OK;
    }
}

nvm_status_t FLASH_PageErase(flash_address_t address)
{
    //Save global interrupt enable bit value
    uint8_t globalInterruptBitValue = INTCONbits.GIE;    
    
    //Load NVMADR with the start address of the memory row
    NVMADRH = (uint8_t) (address >> 8);
    NVMADRL = (uint8_t) address;

    //Access program Flash memory
    NVMCON1bits.NVMREGS = 0;
    
    //Performs an erase operation with the next WR command
    NVMCON1bits.FREE = 1;   
    
    //Enable erase operation
    NVMCON1bits.WREN = 1;    

    //Disable global interrupt
    INTCONbits.GIE = 0; 
    
    //Perform the unlock sequence
    NVMCON2 = unlockKeyLow;
    NVMCON2 = unlockKeyHigh;
    NVMCON1bits.WR = 1;
    
    //Restore global interrupt enable bit value
    INTCONbits.GIE = globalInterruptBitValue;	

    //Disable erase operation
    NVMCON1bits.WREN = 0;      
    
    if (NVMCON1bits.WRERR == 1) 
    {
        return NVM_ERROR;
    } 
    else 
    {
        return NVM_OK;
    }
}

flash_address_t FLASH_PageAddressGet(flash_address_t address)
{
    return (flash_address_t) (address & ((PROGMEM_SIZE - 1U) ^ (PROGMEM_PAGE_SIZE - 1U)));
}

uint16_t FLASH_PageOffsetGet(flash_address_t address)
{
    return (uint16_t) (address & (PROGMEM_PAGE_SIZE - 1U));
}

eeprom_data_t EEPROM_Read(eeprom_address_t address)
{
    //Access EEPROM
    NVMCON1bits.NVMREGS = 1;  
    
    //Load NVMADR with the EEPROM address
    NVMADRH = (uint8_t) (address >> 8);
    NVMADRL = (uint8_t) address;
    
    //Initiate Read
    NVMCON1bits.RD = 1;
    
    return NVMDATL;
}

void EEPROM_Write(eeprom_address_t address, eeprom_data_t data)
{
    //Save global interrupt enable bit value
    uint8_t globalInterruptBitValue = INTCONbits.GIE;

    //Access EEPROM
    NVMCON1bits.NVMREGS = 1;
    
    //Enable write operation
    NVMCON1bits.WREN = 1;

    //Load NVMADR with the EEPROM address
    NVMADRH = (uint8_t) (address >> 8);
    NVMADRL = (uint8_t) address;

    //Load NVMDAT with the desired value
    NVMDATL = data;

    //Disable global interrupt
    INTCONbits.GIE = 0;  
  
    //Perform the unlock sequence
    NVMCON2 = 0x55; 
    NVMCON2 = 0xAA;
    NVMCON1bits.WR = 1;

    //Restore global interrupt enable bit value
    INTCONbits.GIE = globalInterruptBitValue; 

    //Disable write operation
    NVMCON1bits.WREN = 0;
}


inline void NVM_InterruptEnable(void)
{
    PIE7bits.NVMIE = 1;
}

inline void NVM_InterruptDisable(void)
{
    PIE7bits.NVMIE = 0;
}

void NVM_ISR(void)
{
    //The interrupt flag has to be cleared manually
    PIR7bits.NVMIF = 0;
        
    if (NVM_Callback != NULL)
    {
        NVM_Callback();
    }
}

void NVM_CallbackRegister(void (*CallbackHandler)(void))
{
    NVM_Callback = CallbackHandler;
}

