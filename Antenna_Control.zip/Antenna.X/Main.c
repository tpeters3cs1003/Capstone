/* 
 * File:   Main.c
 * Author: Connor
 *
 * Created on November 27, 2025, 11:12 AM
 */

#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
#include "System.h"
#include "I2C.h"

uint8_t x=1;
uint8_t Test = 0;

void main(void)
{
    SYSTEM_Initialize();
    NVM_UnlockKeySet(UNLOCK_KEY); 
    Lock();
    
   // Use the macro from NVM.h
    SolPos = EEPROM_READ(SOL_POS_ADDRESS);
    DeployS = EEPROM_READ(DEPLOYS_ADDRESS);
    Deployed = EEPROM_READ(DEPLOY_ADDRESS);
    StowS = EEPROM_READ(STOWS_ADDRESS);
    Stowed = EEPROM_READ(STOW_ADDRESS);
    Steps = EEPROM_READ(STEPS_ADDRESS);
    FT = EEPROM_READ(FIRST_TIME_ADDRESS);
  
    I2C_BuildTxFrame(MSG_BOOT, SolPos, StowS, DeployS, Stowed, Deployed, Steps);
  
    INTCONbits.GIE = 1;  
    INTCONbits.PEIE = 1;
    
    while (1)      
    {
       //Need to recieve an Deploy and Stow Signals
        CheckPos();   
        UpdateData();
       
       if (Deployed == 0xAA )
       {
           if (DeployS == 0xAA)
           {
            DeployS = 0x55;
            FT = 0;
            PM = 0;
            EN_SetLow();
            STBY_SetLow();
            EEPROM_Write(DEPLOYS_ADDRESS, 0x55);
            while(NVM_IsBusy()){}
           }
             
           if(StowS== 0xAA)
           {
               Stow();
           }  
       }
       
      if (Stowed == 0xAA )
       {
        if (StowS == 0xAA)
           {
            StowS = 0x55;
            FT = 0;
            PM = 0;
            EN_SetLow();
            STBY_SetLow();
            EEPROM_Write(STOWS_ADDRESS, 0x55);
            while(NVM_IsBusy()){}
                   Lock();
           }
           if(DeployS== 0xAA)
           {
               Deploy();
           }
               
       }
       
       if ( Stowed == 0x55 && Deployed == 0x55)
       {
           if (DeployS == 0xAA)
           {
               Deploy();
           }
           else if (StowS == 0xAA)
           {
               Stow();
           }
           // else if request signal 
           else if (DeployS == 0x55 && StowS == 0x55)
           {
               I2C_BuildTxFrame(MSG_ALAC_CMD_REQ, SolPos, StowS, DeployS, Stowed, Deployed, Steps);
           }
       }
    }
}

