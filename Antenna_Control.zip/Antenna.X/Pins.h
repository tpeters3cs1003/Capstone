/* 
 * File:   Pins.h
 * Author: Connor
 *
 * Created on November 27, 2025, 11:34 AM
 */


#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set IO_RA0 aliases
#define STBY_TRIS                 TRISAbits.TRISA0
#define STBY_LAT                  LATAbits.LATA0
#define STBY_PORT                 PORTAbits.RA0
#define STBY_WPU                  WPUAbits.WPUA0
#define STBY_OD                   ODCONAbits.ODCA0
#define STBY_ANS                  ANSELAbits.ANSA0
#define STBY_SetHigh()            do { LATAbits.LATA0 = 1; } while(0)
#define STBY_SetLow()             do { LATAbits.LATA0 = 0; } while(0)
#define STBY_Toggle()             do { LATAbits.LATA0 = ~LATAbits.LATA0; } while(0)
#define STBY_GetValue()           PORTAbits.RA0
#define STBY_SetDigitalInput()    do { TRISAbits.TRISA0 = 1; } while(0)
#define STBY_SetDigitalOutput()   do { TRISAbits.TRISA0 = 0; } while(0)
#define STBY_SetPullup()          do { WPUAbits.WPUA0 = 1; } while(0)
#define STBY_ResetPullup()        do { WPUAbits.WPUA0 = 0; } while(0)
#define STBY_SetPushPull()        do { ODCONAbits.ODCA0 = 0; } while(0)
#define STBY_SetOpenDrain()       do { ODCONAbits.ODCA0 = 1; } while(0)
#define STBY_SetAnalogMode()      do { ANSELAbits.ANSA0 = 1; } while(0)
#define STBY_SetDigitalMode()     do { ANSELAbits.ANSA0 = 0; } while(0)
// get/set IO_RA1 aliases
#define EN_TRIS                 TRISAbits.TRISA1
#define EN_LAT                  LATAbits.LATA1
#define EN_PORT                 PORTAbits.RA1
#define EN_WPU                  WPUAbits.WPUA1
#define EN_OD                   ODCONAbits.ODCA1
#define EN_ANS                  ANSELAbits.ANSA1
#define EN_SetHigh()            do { LATAbits.LATA1 = 1; } while(0)
#define EN_SetLow()             do { LATAbits.LATA1 = 0; } while(0)
#define EN_Toggle()             do { LATAbits.LATA1 = ~LATAbits.LATA1; } while(0)
#define EN_GetValue()           PORTAbits.RA1
#define EN_SetDigitalInput()    do { TRISAbits.TRISA1 = 1; } while(0)
#define EN_SetDigitalOutput()   do { TRISAbits.TRISA1 = 0; } while(0)
#define EN_SetPullup()          do { WPUAbits.WPUA1 = 1; } while(0)
#define EN_ResetPullup()        do { WPUAbits.WPUA1 = 0; } while(0)
#define EN_SetPushPull()        do { ODCONAbits.ODCA1 = 0; } while(0)
#define EN_SetOpenDrain()       do { ODCONAbits.ODCA1 = 1; } while(0)
#define EN_SetAnalogMode()      do { ANSELAbits.ANSA1 = 1; } while(0)
#define EN_SetDigitalMode()     do { ANSELAbits.ANSA1 = 0; } while(0)
// get/set IO_RA2 aliases
#define M1_TRIS                 TRISAbits.TRISA2
#define M1_LAT                  LATAbits.LATA2
#define M1_PORT                 PORTAbits.RA2
#define M1_WPU                  WPUAbits.WPUA2
#define M1_OD                   ODCONAbits.ODCA2
#define M1_ANS                  ANSELAbits.ANSA2
#define M1_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define M1_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define M1_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define M1_GetValue()           PORTAbits.RA2
#define M1_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define M1_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define M1_SetPullup()          do { WPUAbits.WPUA2 = 1; } while(0)
#define M1_ResetPullup()        do { WPUAbits.WPUA2 = 0; } while(0)
#define M1_SetPushPull()        do { ODCONAbits.ODCA2 = 0; } while(0)
#define M1_SetOpenDrain()       do { ODCONAbits.ODCA2 = 1; } while(0)
#define M1_SetAnalogMode()      do { ANSELAbits.ANSA2 = 1; } while(0)
#define M1_SetDigitalMode()     do { ANSELAbits.ANSA2 = 0; } while(0)
// get/set IO_RA3 aliases
#define DIR_M3_TRIS                 TRISAbits.TRISA3
#define DIR_M3_LAT                  LATAbits.LATA3
#define DIR_M3_PORT                 PORTAbits.RA3
#define DIR_M3_WPU                  WPUAbits.WPUA3
#define DIR_M3_OD                   ODCONAbits.ODCA3
#define DIR_M3_ANS                  ANSELAbits.ANSA3
#define DIR_M3_SetHigh()            do { LATAbits.LATA3 = 1; } while(0)
#define DIR_M3_SetLow()             do { LATAbits.LATA3 = 0; } while(0)
#define DIR_M3_Toggle()             do { LATAbits.LATA3 = ~LATAbits.LATA3; } while(0)
#define DIR_M3_GetValue()           PORTAbits.RA3
#define DIR_M3_SetDigitalInput()    do { TRISAbits.TRISA3 = 1; } while(0)
#define DIR_M3_SetDigitalOutput()   do { TRISAbits.TRISA3 = 0; } while(0)
#define DIR_M3_SetPullup()          do { WPUAbits.WPUA3 = 1; } while(0)
#define DIR_M3_ResetPullup()        do { WPUAbits.WPUA3 = 0; } while(0)
#define DIR_M3_SetPushPull()        do { ODCONAbits.ODCA3 = 0; } while(0)
#define DIR_M3_SetOpenDrain()       do { ODCONAbits.ODCA3 = 1; } while(0)
#define DIR_M3_SetAnalogMode()      do { ANSELAbits.ANSA3 = 1; } while(0)
#define DIR_M3_SetDigitalMode()     do { ANSELAbits.ANSA3 = 0; } while(0)
// get/set IO_RA4 aliases
#define STEP_M2_TRIS                 TRISAbits.TRISA4
#define STEP_M2_LAT                  LATAbits.LATA4
#define STEP_M2_PORT                 PORTAbits.RA4
#define STEP_M2_WPU                  WPUAbits.WPUA4
#define STEP_M2_OD                   ODCONAbits.ODCA4
#define STEP_M2_ANS                  ANSELAbits.ANSA4
#define STEP_M2_SetHigh()            do { LATAbits.LATA4 = 1; } while(0)
#define STEP_M2_SetLow()             do { LATAbits.LATA4 = 0; } while(0)
#define STEP_M2_Toggle()             do { LATAbits.LATA4 = ~LATAbits.LATA4; } while(0)
#define STEP_M2_GetValue()           PORTAbits.RA4
#define STEP_M2_SetDigitalInput()    do { TRISAbits.TRISA4 = 1; } while(0)
#define STEP_M2_SetDigitalOutput()   do { TRISAbits.TRISA4 = 0; } while(0)
#define STEP_M2_SetPullup()          do { WPUAbits.WPUA4 = 1; } while(0)
#define STEP_M2_ResetPullup()        do { WPUAbits.WPUA4 = 0; } while(0)
#define STEP_M2_SetPushPull()        do { ODCONAbits.ODCA4 = 0; } while(0)
#define STEP_M2_SetOpenDrain()       do { ODCONAbits.ODCA4 = 1; } while(0)
#define STEP_M2_SetAnalogMode()      do { ANSELAbits.ANSA4 = 1; } while(0)
#define STEP_M2_SetDigitalMode()     do { ANSELAbits.ANSA4 = 0; } while(0)
// get/set IO_RA5 aliases
#define ERR_TRIS                 TRISAbits.TRISA5
#define ERR_LAT                  LATAbits.LATA5
#define ERR_PORT                 PORTAbits.RA5
#define ERR_WPU                  WPUAbits.WPUA5
#define ERR_OD                   ODCONAbits.ODCA5
#define ERR_ANS                  ANSELAbits.ANSA5
#define ERR_SetHigh()            do { LATAbits.LATA5 = 1; } while(0)
#define ERR_SetLow()             do { LATAbits.LATA5 = 0; } while(0)
#define ERR_Toggle()             do { LATAbits.LATA5 = ~LATAbits.LATA5; } while(0)
#define ERR_GetValue()           PORTAbits.RA5
#define ERR_SetDigitalInput()    do { TRISAbits.TRISA5 = 1; } while(0)
#define ERR_SetDigitalOutput()   do { TRISAbits.TRISA5 = 0; } while(0)
#define ERR_SetPullup()          do { WPUAbits.WPUA5 = 1; } while(0)
#define ERR_ResetPullup()        do { WPUAbits.WPUA5 = 0; } while(0)
#define ERR_SetPushPull()        do { ODCONAbits.ODCA5 = 0; } while(0)
#define ERR_SetOpenDrain()       do { ODCONAbits.ODCA5 = 1; } while(0)
#define ERR_SetAnalogMode()      do { ANSELAbits.ANSA5 = 1; } while(0)
#define ERR_SetDigitalMode()     do { ANSELAbits.ANSA5 = 0; } while(0)
// get/set IO_RA7 aliases
#define M0_TRIS                 TRISAbits.TRISA7
#define M0_LAT                  LATAbits.LATA7
#define M0_PORT                 PORTAbits.RA7
#define M0_WPU                  WPUAbits.WPUA7
#define M0_OD                   ODCONAbits.ODCA7
#define M0_ANS                  ANSELAbits.ANSA7
#define M0_SetHigh()            do { LATAbits.LATA7 = 1; } while(0)
#define M0_SetLow()             do { LATAbits.LATA7 = 0; } while(0)
#define M0_Toggle()             do { LATAbits.LATA7 = ~LATAbits.LATA7; } while(0)
#define M0_GetValue()           PORTAbits.RA7
#define M0_SetDigitalInput()    do { TRISAbits.TRISA7 = 1; } while(0)
#define M0_SetDigitalOutput()   do { TRISAbits.TRISA7 = 0; } while(0)
#define M0_SetPullup()          do { WPUAbits.WPUA7 = 1; } while(0)
#define M0_ResetPullup()        do { WPUAbits.WPUA7 = 0; } while(0)
#define M0_SetPushPull()        do { ODCONAbits.ODCA7 = 0; } while(0)
#define M0_SetOpenDrain()       do { ODCONAbits.ODCA7 = 1; } while(0)
#define M0_SetAnalogMode()      do { ANSELAbits.ANSA7 = 1; } while(0)
#define M0_SetDigitalMode()     do { ANSELAbits.ANSA7 = 0; } while(0)
// get/set IO_RB3 aliases
#define ControlS_TRIS                 TRISBbits.TRISB3
#define ControlS_LAT                  LATBbits.LATB3
#define ControlS_PORT                 PORTBbits.RB3
#define ControlS_WPU                  WPUBbits.WPUB3
#define ControlS_OD                   ODCONBbits.ODCB3
#define ControlS_ANS                  ANSELBbits.ANSB3
#define ControlS_SetHigh()            do { LATBbits.LATB3 = 1; } while(0)
#define ControlS_SetLow()             do { LATBbits.LATB3 = 0; } while(0)
#define ControlS_Toggle()             do { LATBbits.LATB3 = ~LATBbits.LATB3; } while(0)
#define ControlS_GetValue()           PORTBbits.RB3
#define ControlS_SetDigitalInput()    do { TRISBbits.TRISB3 = 1; } while(0)
#define ControlS_SetDigitalOutput()   do { TRISBbits.TRISB3 = 0; } while(0)
#define ControlS_SetPullup()          do { WPUBbits.WPUB3 = 1; } while(0)
#define ControlS_ResetPullup()        do { WPUBbits.WPUB3 = 0; } while(0)
#define ControlS_SetPushPull()        do { ODCONBbits.ODCB3 = 0; } while(0)
#define ControlS_SetOpenDrain()       do { ODCONBbits.ODCB3 = 1; } while(0)
#define ControlS_SetAnalogMode()      do { ANSELBbits.ANSB3 = 1; } while(0)
#define ControlS_SetDigitalMode()     do { ANSELBbits.ANSB3 = 0; } while(0)
// get/set IO_RB4 aliases
#define SolB_TRIS                 TRISBbits.TRISB4
#define SolB_LAT                  LATBbits.LATB4
#define SolB_PORT                 PORTBbits.RB4
#define SolB_WPU                  WPUBbits.WPUB4
#define SolB_OD                   ODCONBbits.ODCB4
#define SolB_ANS                  ANSELBbits.ANSB4
#define SolB_SetHigh()            do { LATBbits.LATB4 = 1; } while(0)
#define SolB_SetLow()             do { LATBbits.LATB4 = 0; } while(0)
#define SolB_Toggle()             do { LATBbits.LATB4 = ~LATBbits.LATB4; } while(0)
#define SolB_GetValue()           PORTBbits.RB4
#define SolB_SetDigitalInput()    do { TRISBbits.TRISB4 = 1; } while(0)
#define SolB_SetDigitalOutput()   do { TRISBbits.TRISB4 = 0; } while(0)
#define SolB_SetPullup()          do { WPUBbits.WPUB4 = 1; } while(0)
#define SolB_ResetPullup()        do { WPUBbits.WPUB4 = 0; } while(0)
#define SolB_SetPushPull()        do { ODCONBbits.ODCB4 = 0; } while(0)
#define SolB_SetOpenDrain()       do { ODCONBbits.ODCB4 = 1; } while(0)
#define SolB_SetAnalogMode()      do { ANSELBbits.ANSB4 = 1; } while(0)
#define SolB_SetDigitalMode()     do { ANSELBbits.ANSB4 = 0; } while(0)
// get/set IO_RB5 aliases
#define SolA_TRIS                 TRISBbits.TRISB5
#define SolA_LAT                  LATBbits.LATB5
#define SolA_PORT                 PORTBbits.RB5
#define SolA_WPU                  WPUBbits.WPUB5
#define SolA_OD                   ODCONBbits.ODCB5
#define SolA_ANS                  ANSELBbits.ANSB5
#define SolA_SetHigh()            do { LATBbits.LATB5 = 1; } while(0)
#define SolA_SetLow()             do { LATBbits.LATB5 = 0; } while(0)
#define SolA_Toggle()             do { LATBbits.LATB5 = ~LATBbits.LATB5; } while(0)
#define SolA_GetValue()           PORTBbits.RB5
#define SolA_SetDigitalInput()    do { TRISBbits.TRISB5 = 1; } while(0)
#define SolA_SetDigitalOutput()   do { TRISBbits.TRISB5 = 0; } while(0)
#define SolA_SetPullup()          do { WPUBbits.WPUB5 = 1; } while(0)
#define SolA_ResetPullup()        do { WPUBbits.WPUB5 = 0; } while(0)
#define SolA_SetPushPull()        do { ODCONBbits.ODCB5 = 0; } while(0)
#define SolA_SetOpenDrain()       do { ODCONBbits.ODCB5 = 1; } while(0)
#define SolA_SetAnalogMode()      do { ANSELBbits.ANSB5 = 1; } while(0)
#define SolA_SetDigitalMode()     do { ANSELBbits.ANSB5 = 0; } while(0)
// get/set IO_RC1 aliases
#define LimSwS_TRIS                 TRISCbits.TRISC1
#define LimSwS_LAT                  LATCbits.LATC1
#define LimSwS_PORT                 PORTCbits.RC1
#define LimSwS_WPU                  WPUCbits.WPUC1
#define LimSwS_OD                   ODCONCbits.ODCC1
#define LimSwS_ANS                  ANSELCbits.ANSC1
#define LimSwS_SetHigh()            do { LATCbits.LATC1 = 1; } while(0)
#define LimSwS_SetLow()             do { LATCbits.LATC1 = 0; } while(0)
#define LimSwS_Toggle()             do { LATCbits.LATC1 = ~LATCbits.LATC1; } while(0)
#define LimSwS_GetValue()           PORTCbits.RC1
#define LimSwS_SetDigitalInput()    do { TRISCbits.TRISC1 = 1; } while(0)
#define LimSwS_SetDigitalOutput()   do { TRISCbits.TRISC1 = 0; } while(0)
#define LimSwS_SetPullup()          do { WPUCbits.WPUC1 = 1; } while(0)
#define LimSwS_ResetPullup()        do { WPUCbits.WPUC1 = 0; } while(0)
#define LimSwS_SetPushPull()        do { ODCONCbits.ODCC1 = 0; } while(0)
#define LimSwS_SetOpenDrain()       do { ODCONCbits.ODCC1 = 1; } while(0)
#define LimSwS_SetAnalogMode()      do { ANSELCbits.ANSC1 = 1; } while(0)
#define LimSwS_SetDigitalMode()     do { ANSELCbits.ANSC1 = 0; } while(0)
// get/set IO_RC0 aliases
#define LimSwD_TRIS                 TRISCbits.TRISC0
#define LimSwD_LAT                  LATCbits.LATC0
#define LimSwD_PORT                 PORTCbits.RC0
#define LimSwD_WPU                  WPUCbits.WPUC0
#define LimSwD_OD                   ODCONCbits.ODCC0
#define LimSwD_ANS                  ANSELCbits.ANSC0
#define LimSwD_SetHigh()            do { LATCbits.LATC0 = 1; } while(0)
#define LimSwD_SetLow()             do { LATCbits.LATC0 = 0; } while(0)
#define LimSwD_Toggle()             do { LATCbits.LATC0 = ~LATCbits.LATC0; } while(0)
#define LimSwD_GetValue()           PORTCbits.RC0
#define LimSwD_SetDigitalInput()    do { TRISCbits.TRISC0 = 1; } while(0)
#define LimSwD_SetDigitalOutput()   do { TRISCbits.TRISC0 = 0; } while(0)
#define LimSwD_SetPullup()          do { WPUCbits.WPUC0 = 1; } while(0)
#define LimSwD_ResetPullup()        do { WPUCbits.WPUC0 = 0; } while(0)
#define LimSwD_SetPushPull()        do { ODCONCbits.ODCC0 = 0; } while(0)
#define LimSwD_SetOpenDrain()       do { ODCONCbits.ODCC0 = 1; } while(0)
#define LimSwD_SetAnalogMode()      do { ANSELCbits.ANSC0 = 1; } while(0)
#define LimSwD_SetDigitalMode()     do { ANSELCbits.ANSC0 = 0; } while(0)
/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/