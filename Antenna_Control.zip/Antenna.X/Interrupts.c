#include "Interrupts.h"
#include "System.h"
#include "I2C.h"
#include "Pins.h"



void (*INT_InterruptHandler)(void);



void  INTERRUPT_Initialize (void)

{

    // Clear the interrupt flag

    // Set the external interrupt edge detect

    EXT_INT_InterruptFlagClear();   

    EXT_INT_risingEdgeSet();

    // Set Default Interrupt Handler

   INT_SetInterruptHandler(INT_DefaultInterruptHandler);

     //EXT_INT_InterruptEnable();



}





void INT_ISR(void)

{

    EXT_INT_InterruptFlagClear();



    // Callback function gets called everytime this ISR executes

    INT_CallBack();    

}





void INT_CallBack(void)

{

    // Add your custom callback code here

    if(INT_InterruptHandler)

    {

        INT_InterruptHandler();

    }

}



void INT_SetInterruptHandler(void (* InterruptHandler)(void)){

    INT_InterruptHandler = InterruptHandler;

}



void INT_DefaultInterruptHandler(void){

    // add your INT interrupt custom code

    // or set custom function using INT_SetInterruptHandler()

}


void __interrupt() INTERRUPT_InterruptManager (void)
{
 
    if(INTCONbits.PEIE == 1)
    {    
        if(PIE7bits.NVMIE == 1 && PIR7bits.NVMIF == 1)
        {
            NVM_ISR();
        } 
        else if(PIE3bits.SSP1IE == 1 && PIR3bits.SSP1IF == 1)
        {
            I2C_ISR_Handler();
        }
    }

}
 
/*
void __interrupt() INTERRUPT_InterruptManager (void)
{
    // Handle I2C Standard or Collision events in ONE call
    if ((PIE3bits.SSP1IE && PIR3bits.SSP1IF) || (PIE3bits.BCL1IE && PIR3bits.BCL1IF))
    {
        I2C_ISR_Handler(); 
      
        PIR3bits.BCL1IF = 0;
    }
    
    // Check for any other enabled interrupts that might be hanging
    // If you have an External Interrupt enabled but no handler, it will hang here.
    if (PIE0bits.INTE && PIR0bits.INTF) {
        PIR0bits.INTF = 0; 
    }
}
 * */
/**

 End of File

*/
